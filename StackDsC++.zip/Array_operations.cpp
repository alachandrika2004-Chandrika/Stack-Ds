#include<iostream>
#include "Array.h"
#define MAX 100
using namespace std;

void Array:: insert()
{
    if(!(isFull()))
    {
       int value;
       cout << "Enter the element\n";
       cin >> value;
       arr[size] = value;
       size++;
       cout<< "Element inserted successfully!!\n";
    }
    else
    {
        cout<<"Array is Full\n";
        return;
    }
}

void Array:: deleteElement()
{
    if (isEmpty())
    {
        cout << "Array is Empty\n";
        return;
    }
    int value;
    cout<< "Enter the element to be deleted\n";
    cin >> value;
    int flag = 0;
    for(int i = 0 ; i < size; i++)
    {
        flag = 0;
        if(arr[i] == value)
        {
            flag = 1;
            for (int j = i; j < size - 1; j++)   // Shift loop
            {
               // Shift elements
               arr[j] = arr[j+1];
            }
            cout<< "element deleted successfully\n";
            size--;
        }
        else{
           flag = 0; 
        }
    }
    if(flag == 0) cout<< "Element is not present in the Array\n";
}

bool Array :: isFull()
{
   return size == MAX;
}

bool Array :: isEmpty()
{
    return size == 0;
}

void Array :: average()
{
    int sum = 0;
    if(isEmpty())
    {
        cout << "Array is Empty\n";
        return;
    }
    for(int i = 0; i < size; i++)
    {
        sum += arr[i];
    }
    cout <<"The Average : ";
    cout << sum/size << endl;
}

int compare( const void * a, const void * b)
{
    return *(int*)a - *(int*)b;
}
void Array :: sort()
{
    qsort(arr, size, sizeof(int), compare);
}
void Array :: findMinimum()
{
    if(isEmpty())
    {
        cout << "Array is Empty\n";
        return;
    }
    int min = arr[0];
    for(int i = 1; i< size; i++)
    {
        if(min > arr[i])
        {
            min = arr[i];
        }
    }
    cout << "Minimum : ";
    cout << min;
}

void Array :: findMaximum()
{
    if(isEmpty())
    {
        cout << "Array is Empty\n";
        return;
    }
    int max = arr[0];
    for(int i = 1; i< size; i++)
    {
        if(max < arr[i])
        {
            max = arr[i];
        }
    }
    cout << "Maximum : ";
    cout << max;
}

void Array :: reverse()
{
    for(int i = 0; i < size/2; i++)
    {
        int temp= arr[i];
        arr[i]= arr[size-1-i];
        arr[size-1-i]= temp;
    }
    cout<<"Array reversed successfully\n";
}

void Array :: display()
{
    cout<<"==================Display=================\n";
    if(isEmpty())
    {
       cout<<"Array is Empty";
       return;
    }
    cout<<"Array elements: ";
    for(int i = 0; i< size; i++)
    {
        cout<< arr[i] << ' ';
    }
    cout<<endl;
}

void Array :: update()
{
    int value, updated_value;
    cout<< " Enter the value to update: ";
    cin >> value >> updated_value;
    int flag = 0;
    for(int i = 0 ; i < size; i++)
    {
        if( arr[i] == value)
        {
            flag = 1;
            arr[i] = updated_value;
            cout<<"Updation is done!!\n";
        }
        else flag = 0;
    }
    if(flag == 0) cout<<"value is not present\n";
}

void Array :: search()
{
    int value;
    cout<< " Enter the value you wanted to search: ";
    cin >> value;
    int flag = 0;
    for(int i = 0 ; i < size; i++)
    {
        if(arr[i] == value)
        {
            flag = 1;
            cout<< "The value is found at index" << i;
            break;
        }
    }
    if(flag != 1)
    cout<<"Not found!!\n";
}

void Array::sum()
{
    int sum = 0;
    if(isEmpty())
    {
        cout << "Array is Empty\n";
        return;
    }
    for(int i = 0; i < size; i++)
    {
        sum += arr[i];
    }
    cout <<"The Sum : ";
    cout << sum << endl;
}

