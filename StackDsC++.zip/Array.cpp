#include<iostream>
#include"Array.h"

using namespace std;

Array::Array()
{
    size = 0;
}

void Array::menu()
{
    int choice;
    do{
    cout<<"===============ARRAY MENU=====================\n";
    cout<<"1. Insert\n";
    cout<<"2. Delete Element\n";
    cout<<"3. Search\n";
    cout<<"4. Update\n";
    cout<<"5. Display\n";
    cout<<"6. Reverse\n";
    cout<<"7. Sort\n";
    cout<<"8. Find Maximum\n";
    cout<<"9. Find Minimum\n";
    cout<<"10. Sum\n";
    cout<<"11. Average\n";
    cout<<"12. isEmpty\n";
    cout<<"13. isFull\n";
    cout <<"14. Exit\n";
    cout<<"Enter your choice of operation: ";
    cin>> choice;

    switch(choice)
    {
        case 1: insert();
                break;
        case 2: deleteElement();
                break;
        case 3: search();
                break;
        case 4: update();
                break;
        case 5: display();
                break;
        case 6: reverse();
                break;
        case 7: sort();
                break;
        case 8: findMaximum();
                break;
        case 9: findMinimum();
                break;
        case 10:sum();
                break;
        case 11:average();
                break;
        case 12:if(isEmpty())
                    cout << "Array is Empty\n";
                else
                    cout << "Array is Not Empty\n";
                break;
        case 13:if(isFull())
                    cout << "Array is Full\n";
                else
                    cout << "Array is Not Full\n";
                break;
        case 14:cout << "Exiting Array Menu...\n"; 
                break;
        default:cout<<"Invalid choice!! Try again\n";

    }
}while(choice != 14);
    
}