#ifndef QUEUE_H
#define QUEUE_H

class Queue
{
private:
    int queue[100];
    int front;
    int rear;

public:
    Queue();

    void menu();

    void enqueue();
    void dequeue();
    void peek();
    void display();

    bool isEmpty();
    bool isFull();
};

#endif