#ifndef LINKEDLIST_H
#define LINKEDLIST_H

class Node
{
public:
    int data;
    Node* next;
};

class LinkedList
{
private:
    Node* head;

public:
    LinkedList();

    void menu();

    void insertAtBeginning();
    void insertAtEnd();
    void insertAtPosition();

    void deleteAtBeginning();
    void deleteAtEnd();
    void deleteAtPosition();

    void search();
    void update();
    void display();
    void reverse();

    bool isEmpty();
};

#endif

