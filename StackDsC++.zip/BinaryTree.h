#ifndef BINARYTREE_H
#define BINARYTREE_H

class TreeNode
{
public:
    int data;
    TreeNode* left;
    TreeNode* right;
};

class BinaryTree
{
private:
    TreeNode* root;

    TreeNode* insert(TreeNode* root, int value);
    TreeNode* search(TreeNode* root, int value);

    void inorder(TreeNode* root);
    void preorder(TreeNode* root);
    void postorder(TreeNode* root);

public:
    BinaryTree();

    void menu();

    void insert();
    void search();
    void inorder();
    void preorder();
    void postorder();

    bool isEmpty();
};

#endif