#ifndef ARRAY_H
#define ARRAY_H

class Array{
    private:
    int arr[100];
    int size;

    public:
    Array();

    void menu();
    // Core Operations
    void insert();
    void deleteElement();
    void search();
    void update();
    void display();

    // Utility Operations
    void reverse();
    void sort();
    void findMaximum();
    void findMinimum();
    void sum();
    void average();

    // Validation Functions
    bool isEmpty();
    bool isFull();
};
#endif