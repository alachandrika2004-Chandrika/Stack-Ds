#include <iostream>
#include "BinaryTree.h"

using namespace std;


void BinaryTree::menu()
{
    int choice;

    do
    {
        cout << "\n========== BINARY TREE MENU ==========\n";
        cout << "1. Insert\n";
        cout << "2. Search\n";
        cout << "3. Inorder\n";
        cout << "4. Preorder\n";
        cout << "5. Postorder\n";
        cout << "6. isEmpty\n";
        cout << "7. Exit\n";

        cout << "Enter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1: insert(); break;
            case 2: search(); break;
            case 3: inorder(); break;
            case 4: preorder(); break;
            case 5: postorder(); break;

            case 6:
                if(isEmpty())
                    cout << "Tree is Empty\n";
                else
                    cout << "Tree is Not Empty\n";
                break;

            case 7:
                break;

            default:
                cout << "Invalid choice\n";
        }

    } while(choice != 7);
}