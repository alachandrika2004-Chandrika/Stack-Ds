#include<iostream>
#include "stack.h"
#define MAX 100
using namespace std;

void Stack:: push()
{
    int value;
    cout << "Enter the element\n";
    cin >> value;
    if(isFull())
    {
      cout<<"Stack Overflow";
      return;
    }
    stack[++top] = value;
    cout<<value << ' ' <<"Pushed into stack successfully!!\n";
}

void Stack:: pop()
{
    if (isEmpty())
    {
        cout << "Stack is Empty\n";
        return;
    }
    cout<<stack[top]<<' ' <<"is popped successfully\n";
    top--;
}

bool Stack :: isFull()
{
   return top == MAX-1;
}

bool Stack :: isEmpty()
{
    return top == -1;
}

void Stack:: peek()
{
    if(isEmpty())
    {
       cout << "Stack is Empty";
       return;
    }
    cout<< stack[top]<< endl;
}

void Stack :: display()
{
    cout<<"==================Display=================\n";
    if(isEmpty())
    {
       cout<<"Stack is Empty";
       return;
    }
    cout<<"Stack elements: ";
    for(int i = 0; i<= top; i++)
    {
        cout<< stack[i] <<"\n";
    }
    cout<<endl;
}