#include <iostream>
#include "LinkedList.h"

using namespace std;

void LinkedList::menu()
{
    int choice;

    do
    {
        cout << "\n========== LINKED LIST MENU ==========\n";
        cout << "1. Insert at Beginning\n";
        cout << "2. Insert at End\n";
        cout << "3. Insert at Position\n";
        cout << "4. Delete at Beginning\n";
        cout << "5. Delete at End\n";
        cout << "6. Delete at Position\n";
        cout << "7. Search\n";
        cout << "8. Update\n";
        cout << "9. Display\n";
        cout << "10. Reverse\n";
        cout << "11. isEmpty\n";
        cout << "12. Exit\n";

        cout << "Enter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1: insertAtBeginning(); 
                    break;
            case 2: insertAtEnd(); 
                    break;
            case 3: insertAtPosition(); 
                    break;
            case 4: deleteAtBeginning(); 
                    break;
            case 5: deleteAtEnd(); 
                    break;
            case 6: deleteAtPosition(); 
                    break;
            case 7: search(); 
                    break;
            case 8: update(); 
                    break;
            case 9: display(); 
                    break;
            case 10: reverse(); 
                     break;
            case 11: if(isEmpty())
                       cout << "List is Empty\n";
                     else
                       cout << "List is Not Empty\n";
                     break;
            case 12: cout<<"Exiting Linkedlist Menu..\n";
                     break;
            default:
                cout << "Invalid choice\n";
        }

    } while(choice != 12);
}