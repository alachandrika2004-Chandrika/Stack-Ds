#include<iostream>
#include"queue.h"
#define MAX 100
using namespace std;


bool Queue::isEmpty(){
    return front == -1;
}

bool Queue::isFull()
{
    return rear == MAX - 1;
}

void Queue::enqueue()
{
    if(isFull()) {
        cout<<"Queue overflow\n";
        return;
    }
    else
    {
        int value;
        cout<<"Enter Enqueue: ";
        cin>>value;
        if(isEmpty())
        {
            front = 0;
        }
        rear++;
        queue[rear]= value;
    }
    cout << "Element enqueued successfully.\n";
}


void Queue::dequeue()
{
    if(!isEmpty())
    {
        cout << "Dequeued element: " << queue[front] << endl;
        front++;
        if(front > rear)
        {
            front = rear = -1;
        }
    }
    else{
        cout<<"Queue Underflow\n";
        return;
    }
}

void Queue::peek()
{
    if(isEmpty())
    {
        cout<<"Queue is Empty\n";
        return;
    }
    cout << "Front element: " << queue[front] << endl;
}

void Queue::display()
{
    if(isEmpty())
    {
        cout << "Queue is Empty\n";
        return;
    }
    cout << "Queue: ";
    for(int i = front; i <=rear; i++)
    {
        cout<<queue[i]<< " ";;
    }
    cout << endl;
}