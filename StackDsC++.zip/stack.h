#ifndef STACK_H
#define STACK_H

class Stack
{
private:
    int stack[100];
    int top;

public:
    Stack();

    void menu();
    void push();
    void pop();
    void peek();
    void display();
    bool isEmpty();
    bool isFull();
};

#endif