#include <iostream>
#include "Array.h"
#include "Stack.h"
#include "Queue.h"
#include "LinkedList.h"
#include "BinaryTree.h"

using namespace std;

int main()
{
    Array arr;
    Stack stack;
    Queue queue;
    LinkedList list;
    BinaryTree tree;
    int choice;

    do
    {
        cout << "==================== MAIN MENU ====================\n";
        cout << "1. Array\n";
        cout << "2. Stack\n";
        cout << "3. Queue\n";
        cout << "4. Linked List\n";
        cout << "5. Binary Tree\n";
        cout << "6. Exit\n";

        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
            {
                Array arr;
                arr.menu();
                break;
            }

            case 2:
            {
                Stack st;
                stack.menu();
                break;
            }

            case 3:
            {
                Queue queue;
                queue.menu();
                break;
            }

            case 4:
            {
                LinkedList list;
                list.menu();
                break;
            }

            case 5:
            {
                BinaryTree tree;
                tree.menu();
                break;
            }

            case 6:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while(choice != 6);

    return 0;
}