#include <iostream>
#include "LinkedList.h"

using namespace std;

LinkedList::LinkedList()
{
    head = nullptr;
}

bool LinkedList::isEmpty()
{
    return head == nullptr;
}

void LinkedList::insertAtBeginning()
{
    int value;
    cout << "Enter element: ";
    cin >> value;

    Node* newNode = new Node;

    newNode->data = value;
    newNode->next = head;
    head = newNode;

    cout << "Element inserted successfully\n";
}

void LinkedList::insertAtEnd()
{
    int value;
    cout << "Enter element: ";
    cin >> value;

    Node* newNode = new Node;

    newNode->data = value;
    newNode->next = nullptr;

    if(isEmpty())
    {
        head = newNode;
        return;
    }

    Node* temp = head;

    while(temp->next != nullptr)
    {
        temp = temp->next;
    }

    temp->next = newNode;
}

void LinkedList::insertAtPosition()
{
    int value, position;

    cout << "Enter element: ";
    cin >> value;

    cout << "Enter position: ";
    cin >> position;

    if(position <= 0)
    {
        cout << "Invalid position\n";
        return;
    }

    if(position == 1)
    {
        Node* newNode = new Node;
        newNode->data = value;
        newNode->next = head;
        head = newNode;
        return;
    }

    Node* temp = head;

    for(int i = 1; i < position - 1 && temp != nullptr; i++)
    {
        temp = temp->next;
    }

    if(temp == nullptr)
    {
        cout << "Invalid position\n";
        return;
    }

    Node* newNode = new Node;

    newNode->data = value;
    newNode->next = temp->next;
    temp->next = newNode;
}

void LinkedList::deleteAtBeginning()
{
    if(isEmpty())
    {
        cout << "List is Empty\n";
        return;
    }

    Node* temp = head;
    head = head->next;

    delete temp;
}

void LinkedList::deleteAtEnd()
{
    if(isEmpty())
    {
        cout << "List is Empty\n";
        return;
    }

    if(head->next == nullptr)
    {
        delete head;
        head = nullptr;
        return;
    }

    Node* temp = head;

    while(temp->next->next != nullptr)
    {
        temp = temp->next;
    }

    delete temp->next;
    temp->next = nullptr;
}

void LinkedList::deleteAtPosition()
{
    if(isEmpty())
    {
        cout << "List is Empty\n";
        return;
    }

    int position;
    cout << "Enter position: ";
    cin >> position;

    if(position <= 0)
    {
        cout << "Invalid position\n";
        return;
    }

    if(position == 1)
    {
        deleteAtBeginning();
        return;
    }

    Node* temp = head;

    for(int i = 1; i < position - 1 && temp != nullptr; i++)
    {
        temp = temp->next;
    }

    if(temp == nullptr || temp->next == nullptr)
    {
        cout << "Invalid position\n";
        return;
    }

    Node* deleteNode = temp->next;

    temp->next = deleteNode->next;

    delete deleteNode;
}

void LinkedList::search()
{
    if(isEmpty())
    {
        cout << "List is Empty\n";
        return;
    }

    int value;
    cout << "Enter element to search: ";
    cin >> value;

    Node* temp = head;

    while(temp != nullptr)
    {
        if(temp->data == value)
        {
            cout << "Element found\n";
            return;
        }

        temp = temp->next;
    }

    cout << "Element not found\n";
}

void LinkedList::update()
{
    if(isEmpty())
    {
        cout << "List is Empty\n";
        return;
    }

    int value, newValue;

    cout << "Enter element: ";
    cin >> value;

    cout << "Enter new value: ";
    cin >> newValue;

    Node* temp = head;

    while(temp != nullptr)
    {
        if(temp->data == value)
        {
            temp->data = newValue;
            cout << "Element updated\n";
            return;
        }

        temp = temp->next;
    }

    cout << "Element not found\n";
}

void LinkedList::display()
{
    if(isEmpty())
    {
        cout << "List is Empty\n";
        return;
    }

    Node* temp = head;

    cout << "List: ";

    while(temp != nullptr)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

void LinkedList::reverse()
{
    Node* previous = nullptr;
    Node* current = head;
    Node* next = nullptr;

    while(current != nullptr)
    {
        next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }

    head = previous;
}

