#include <iostream>
#include "BinaryTree.h"

using namespace std;

BinaryTree::BinaryTree()
{
    root = nullptr;
}

bool BinaryTree::isEmpty()
{
    return root == nullptr;
}

TreeNode* BinaryTree::insert(TreeNode* root, int value)
{
    if(root == nullptr)
    {
        TreeNode* newNode = new TreeNode;

        newNode->data = value;
        newNode->left = nullptr;
        newNode->right = nullptr;

        return newNode;
    }

    if(value < root->data)
    {
        root->left = insert(root->left, value);
    }
    else if(value > root->data)
    {
        root->right = insert(root->right, value);
    }
    else
    {
        cout << "Duplicate element not allowed\n";
    }

    return root;
}

void BinaryTree::insert()
{
    int value;

    cout << "Enter element: ";
    cin >> value;

    root = insert(root, value);

    cout << "Element inserted successfully\n";
}

TreeNode* BinaryTree::search(TreeNode* root, int value)
{
    if(root == nullptr)
    {
        return nullptr;
    }

    if(root->data == value)
    {
        return root;
    }

    if(value < root->data)
    {
        return search(root->left, value);
    }

    return search(root->right, value);
}

void BinaryTree::search()
{
    if(isEmpty())
    {
        cout << "Tree is Empty\n";
        return;
    }

    int value;

    cout << "Enter element to search: ";
    cin >> value;

    if(search(root, value) != nullptr)
    {
        cout << "Element found\n";
    }
    else
    {
        cout << "Element not found\n";
    }
}

void BinaryTree::inorder(TreeNode* root)
{
    if(root == nullptr)
    {
        return;
    }

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}


void BinaryTree::inorder()
{
    if(isEmpty())
    {
        cout << "Tree is Empty\n";
        return;
    }

    cout << "Inorder: ";
    inorder(root);
    cout << endl;
}

void BinaryTree::preorder(TreeNode* root)
{
    if(root == nullptr)
    {
        return;
    }

    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}

void BinaryTree::preorder()
{
    if(isEmpty())
    {
        cout << "Tree is Empty\n";
        return;
    }

    cout << "Preorder: ";
    preorder(root);
    cout << endl;
}

void BinaryTree::postorder(TreeNode* root)
{
    if(root == nullptr)
    {
        return;
    }

    postorder(root->left);
    postorder(root->right);
    cout << root->data << " ";
}

void BinaryTree::postorder()
{
    if(isEmpty())
    {
        cout << "Tree is Empty\n";
        return;
    }

    cout << "Postorder: ";
    postorder(root);
    cout << endl;
}