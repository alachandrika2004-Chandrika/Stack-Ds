#include<iostream>
#include "stack.h"
using namespace std;

Stack :: Stack(){
    top = -1;
}

void Stack :: menu()
{
    int choice;
    do{
    cout<< "===================STACK MENU===================\n";
    cout<< "1. push\n";
    cout<< "2. pop\n";
    cout<< "3. peek\n";
    cout<< "4. display\n";
    cout<< "5. isEmpty\n";
    cout<< "6. isFull\n";
    cout<< "7. Exit\n";
    cout<< "Enter your choice: ";
    cin >> choice;
    switch(choice)
    {
        case 1: push();
                break;
        case 2: pop();
                break;
        case 3: peek();
                break;
        case 4: display();
                break;
        case 5: if(isEmpty())
                   cout<<"Stack is Empty\n";
                else
                   cout<<"Stack is not Empty\n";
                break;
        case 6: if(isFull())
                    cout<<"Stack is Full\n";
                else
                    cout<<"Stack is not full\n";
                break;
        case 7: cout<<"Exiting Stack Menu...\n";
                break;
        default:cout<<"Invalid choice, Try again!!";
    }
    }while(choice != 7);
}