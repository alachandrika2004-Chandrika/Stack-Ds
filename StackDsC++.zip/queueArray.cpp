#include<iostream>
#include"queue.h"
using namespace std;


Queue::Queue()
{
    front = -1;
    rear = -1;
}

void Queue::menu()
{
    int choice;
    do
    {
        cout << "\n========== QUEUE MENU ==========\n";
        cout << "1. Enqueue\n";
        cout << "2. Dequeue\n";
        cout << "3. Peek\n";
        cout << "4. Display\n";
        cout << "5. isEmpty\n";
        cout << "6. isFull\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                enqueue();
                break;

            case 2:
                dequeue();
                break;

            case 3:
                peek();
                break;

            case 4:
                display();
                break;

            case 5:
                if(isEmpty())
                    cout << "Queue is Empty\n";
                else
                    cout << "Queue is Not Empty\n";
                break;

            case 6:
                if(isFull())
                    cout << "Queue is Full\n";
                else
                    cout << "Queue is Not Full\n";
                break;

            case 7:
                cout << "Exiting Queue Menu...\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while(choice != 7);
}